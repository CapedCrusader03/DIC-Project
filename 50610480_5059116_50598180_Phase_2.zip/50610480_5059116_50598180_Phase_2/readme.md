Name	Email ID	UB Number
Kshitij Kumar	kkumar8@buffalo.edu	50610480
Amritesh Kuraria	akuraria@buffalo.edu	50598180
Shubham Shubham	shubham@buffalo.edu	50596116

Kshitij Hypothesis 1: How is the research paper trending over time? Is it growing, declining or remaining stable over time?

Kshitij Hypothesis 2: What are the healthcare innovations that can be derived from all the research papers published? Is there some topics that contribute to AI-driven healthcare innovations?

Amritesh Hypothesis 1: Majority of authors publish research article in a single specialized field,But a section of authors engages in interdisciplinary work.

Amritesh Hypothesis 2: There is a significant difference between the number of author per paper accorss different categories. i.e in some category there are more number of author working togather on a paper than other category

Shubham Hypothesis 1: Research growth in listed category for the last decade vs previous year

Shubham Hypothesis 2: Research Growth between interconnected category in last decade


Folder structure:

inside parent foldeer:
Amritesh's ipynb files: Amritesh_hypo2.ipynb and Amritesh_hypo1.ipynb
Kshitij's ipynb files: 50610480_Kshitij_Hypothesis_1.ipynb, 50610480_Kshitij_Hypothesis_1.ipynb
Shubham's ipynb files: Phase21.ipynb
